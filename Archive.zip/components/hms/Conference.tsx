import React from 'react';
import VideoList from './VideoList';

const List = () => {
  return <VideoList />;
};

export default List;
